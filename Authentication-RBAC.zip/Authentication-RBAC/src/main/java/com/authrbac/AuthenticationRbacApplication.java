package com.authrbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationRbacApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationRbacApplication.class, args);
		System.out.println("Hello");
	}

}
