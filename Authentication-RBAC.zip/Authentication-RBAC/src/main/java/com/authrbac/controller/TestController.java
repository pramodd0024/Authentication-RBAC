package com.authrbac.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class TestController {

    @GetMapping("/user")
    public String user() {
        return "User content";
    }

    @GetMapping("/admin")
    public String admin() {
        return "Admin content";
    }
}