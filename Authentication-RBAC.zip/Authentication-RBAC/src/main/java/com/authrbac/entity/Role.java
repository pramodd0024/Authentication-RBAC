package com.authrbac.entity;

public enum Role {
    USER,
    ADMIN
}